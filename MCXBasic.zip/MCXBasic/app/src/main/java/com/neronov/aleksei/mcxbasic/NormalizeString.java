package com.neronov.aleksei.mcxbasic;

import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.neronov.aleksei.mcxbasic.GlobalVars.getInstance;

/**
 * Created by Aleksei Neronov on 15.03.16.
 */
public class NormalizeString {
    private static final int NSNotFound = -1;
    private static final boolean NO = false;
    private static final boolean YES = true;
    private static final String TAG = MainActivity.class.getSimpleName();

    DigitalFunc digitalFunc;
    StringFunc stringFunc;

    public String replaceCharWithCharInText(char sign, char witbSign, String string) {
        String result = "";
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.charAt(i) == '"' && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                }
                if (string.charAt(i) == '"' && foundFirst && indexFirst != i) foundFirst = NO;
                if (foundFirst) result = result + string.substring(i, i + 1);
                if (!foundFirst && string.charAt(i) !=sign) result = result + string.substring(i, i + 1);
                if (!foundFirst && string.charAt(i) ==sign) result = result + witbSign;
            }
        }
        return result;
    }

    public String lowcaseWithText(String string) {
        String result = "";
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                }
                if (foundFirst) {
                    result = result + string.substring(i, i + 1);
                }
                if (!foundFirst) {
                    result = result + string.substring(i, i + 1).toLowerCase();
                }
            }
        }
        return result;
    }

    public String removeSpacesWithText(String string) {
        String result = "";
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {

                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                }
                if (foundFirst) {
                    result = result + string.substring(i, i + 1);
                }
                if (!foundFirst && !string.substring(i, i + 1).equals(" ")) {
                    result = result + string.substring(i, i + 1);
                }
            }
        }
        return result;
    }

    public String removeSpaceInBegin(String string) {
        int i = 0;
        while (i < string.length() && string.substring(i, i + 1).equals(" ")) i++;
        return string.substring(i);
    }

    public String removeSpaceInBeginAndEnd(String string) {
        return string.trim();
    }

    public String removeText(String string) {
        ArrayList arr = new ArrayList();
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                    NSRange range = new NSRange(indexFirst, i - indexFirst + 1);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
            }
        } else {
            getInstance().error = "Syntax error\n";
        }
        if (foundFirst) {
            getInstance().error = "Syntax error\n";
        } else {
            for (int i = 0; i < arr.size(); i++) {
                //Log.d(TAG, "± removeText->" + arr.get(i).toString());
                string = string.replaceAll(arr.get(i).toString(), "");
            }
        }
        return string;
    }

    public boolean insideText(String string, int index) {
        int indexFirst = 0;
        boolean foundFirst = NO;
        boolean result = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                }
                if (foundFirst && i == index) {
                    result = YES;
                }
            }
        }
        return result;
    }

    public boolean isPairedQuotes(String string) {
        Log.d(TAG, "± isPairedQuotes " + string);
        int indexFirst = 0;
        boolean foundFirst = NO;
        boolean result = YES;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    result = NO;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                    result = YES;
                }
            }
        }
        return result;
    }

    public boolean isText(String string) {
        boolean foundFirst = NO;
        boolean result = NO;
        if (string.length() > 0) {
            if (string.substring(0, 1).equals("\"")) foundFirst = YES;
            if (string.substring(string.length() - 1).equals("\"") && foundFirst) result = YES;
        }
        return result;
    }

    public boolean isPairedBracket(String string) {
        int indexFirst = 0;
        boolean foundFirst = NO;
        boolean result = YES;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("(") && !foundFirst) {
                    foundFirst = YES;
                    result = NO;
                    indexFirst = i;
                }
                if (string.substring(i, i + 1).equals(")") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                    result = YES;
                }
            }
        }
        return result;
    }

    public List extractNumToArray(String string) {
        List<String> arr = Arrays.asList(string.split(","));
        return arr;
    }

    public ArrayList extractTextToArray(String string) {
        ArrayList arr = new ArrayList();
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i + 1;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i + 1) {
                    foundFirst = NO;
                    NSRange range = new NSRange(indexFirst, i - indexFirst);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
            }
        } else {
            getInstance().error = "Syntax error\n";
        }

        if (foundFirst || arr.size() != 2) {
            getInstance().error = "Syntax error\n";
        } else {
            Log.d(TAG, "± extracted Text->" + arr);
        }
        return arr;
    }

    public ArrayList extractTextAndOtherToArray(String string) {
        ArrayList arr = new ArrayList();
        int index = 0;
        int indexFirst = 0;
        boolean foundFirst = NO;
        boolean haveText = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i;
                    NSRange range = new NSRange(index, i - index);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i) {
                    foundFirst = NO;
                    index = i + 1;
                    haveText = YES;
                    NSRange range = new NSRange(indexFirst, i - indexFirst + 1);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
            }
            if (!haveText) {
                arr.add(string);
            } else {
                NSRange range = new NSRange(index, string.length() - index);
                arr.add(string.substring(range.location, range.location + range.length));
            }
        } else {
            getInstance().error = "Syntax error\n";
        }
        //Log.d(TAG, "± extract TextAndOther To Array ->" + arr);
        return arr;
    }

    public ArrayList extractTextAndNumToArray(String string) {
        ArrayList arr = new ArrayList();
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i + 1;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i + 1) {
                    foundFirst = NO;
                    NSRange range = new NSRange(indexFirst, i - indexFirst);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
                if (string.substring(i, i + 1).equals("+") || string.substring(i, i + 1).equals(",")) {
                    foundFirst = NO;
                    NSRange range = new NSRange(i + 1, string.length() - i - 1);
                    String str = string.substring(range.location, range.location + range.length);
                    if (str.indexOf(',') != NSNotFound) str = str.split(",")[0];
                    arr.add(str);
                }
            }
        } else {
            getInstance().error = "Syntax error\n";
        }
        if (foundFirst || arr.size() < 2) {
            getInstance().error = "Syntax error\n";
        } else {
            Log.d(TAG, "± extract TextAndNum To Array ->" + arr);
        }

        return arr;
    }


    public ArrayList stringSeparateToArray(String string) {
        ArrayList arr = new ArrayList();
        int arrIndex = 0;
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i + 1;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i + 1) {
                    foundFirst = NO;
                }
                if (string.substring(i, i + 1).equals(",") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    arrIndex = i + 1;
                    arr.add(string.substring(range.location, range.location + range.length));
                }
                if (string.substring(i, i + 1).equals("+") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                    }
                }
                if (i == string.length() - 1) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex + 1);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
            }
            //  склеиваем если функция
            Log.d(TAG, "± 1...Separated TEXT - %@" + arr);

            for (int i = 0; i < arr.size(); i++) {
                if (arr.get(i).toString().length() > 4) {
                    String tmp = arr.get(i).toString().substring(0, 5).trim();
                    if (tmp.equals("instr")) {
                        arr.set(i, arr.get(i).toString() + "," + arr.get(i + 1).toString());
                        arr.remove(i + 1);
                    }
                }
            }
            ArrayList arrStr = new ArrayList();
            arrStr = stringAndDigitsSeparateToArray(string);
            ArrayList arrValue = new ArrayList(arrStr);
            if (string.substring(0, 1).equals("-")) {
                arrValue.remove(0);
                arrValue.set(0, "-" + arrValue.get(0).toString());
            }
            int index = 0;
            ArrayList arrSign = new ArrayList();
            for (int i = 0; i < arr.size() - 1; i++) {
                try {
                    index = Integer.parseInt(arr.get(1).toString());
                } catch (NumberFormatException e) {
                    Log.d(TAG, "± Wrong number format in left$!");
                }
                index = index + arr.get(i).toString().length() + 1;
                NSRange range = new NSRange(index - 1, 1);
                arrSign.add(string.substring(range.location, range.location + range.length));
            }
            boolean adding = NO;
            int indAdd = 0;
            ArrayList arrValueDelete = new ArrayList();
            if (arrValue.size() > 2) for (int i = 0; i < arr.size() - 1; i++) {
                String notext = removeText(arr.get(i).toString());
                if (digitalFunc.mathFunction(notext)) {
                    adding = YES;
                    indAdd = i;
                }
                if (adding) {
                    String addString = arr.get(indAdd).toString() + arrSign.get(i).toString() + arr.get(i + 1).toString();
                    arrValueDelete.add(arr.get(i + 1).toString());
                    arr.set(indAdd, addString);
                }
                if (arr.get(i + 1).toString().contains(")")) {
                    adding = NO;
                }
            }
            for (int ii = 0; ii < arrValueDelete.size(); ii++) arr.remove(arrValueDelete.get(ii));
            arrValueDelete.clear();
            adding = NO;
            indAdd = 0;
            for (int ii = 0; ii < arrValueDelete.size(); ii++)
                Log.d(TAG, "± ARR --- " + arr.get(ii).toString());
            if (arrValue.size() > 1) for (int i = 0; i < arr.size() - 1; i++) {
                String notext = removeText(arr.get(i).toString());
                if (stringFunc.stringFunction(notext)) {
                    adding = YES;
                    indAdd = i;
                    Log.d(TAG, "± adding " + notext);
                }
                if (adding) {
                    String addString = arr.get(indAdd).toString() + arrSign.get(i).toString() + arr.get(i + 1).toString();
                    arrValueDelete.add(arr.get(i + 1).toString());
                    arr.set(indAdd, addString);
                }
                if (arr.get(i + 1).toString().contains(")")) {
                    adding = NO;
                }
            }
            for (int ii = 0; ii < arrValueDelete.size(); ii++) arr.remove(arrValueDelete.get(ii));
            for (int i = 0; i < arr.size(); i++) arr.set(i, arr.get(i).toString().trim());
        }
        if (foundFirst) {
            getInstance().error = "Syntax error\n";
        } else {
            for (int i = 0; i < arr.size(); i++)
                Log.d(TAG, "± Separated TEXT->'" + arr.get(i).toString() + "'");
        }
        return arr;
    }


    public ArrayList stringAndDigitsSeparateToArray(String string) {
        ArrayList arr = new ArrayList();
        int arrIndex = 0;
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i + 1;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i + 1) {
                    foundFirst = NO;
                }
                if (string.substring(i, i + 1).equals("+") || string.substring(i, i + 1).equals("-")
                        || string.substring(i, i + 1).equals("/") || string.substring(i, i + 1).equals("*")
                        || string.substring(i, i + 1).equals("^") || string.substring(i, i + 1).equals(",") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    arrIndex = i + 1;
                    arr.add(string.substring(range.location, range.location + range.length));
                }
                if (i == string.length() - 1) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex + 1);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
                //Log.d(TAG, "±  -->'" + string.substring(i, i + 1));
            }
            for (int i = 0; i < arr.size(); i++) {
                if (arr.get(i).toString().length() > 4) {
                    String tmp = arr.get(i).toString().substring(0, 5).trim();
                    if (tmp.equals("instr")) {
                        arr.set(i, arr.get(i).toString() + "," + arr.get(i + 1).toString());
                        arr.remove(i + 1);
                    }
                }
            }
            for (int i = 0; i < arr.size(); i++) arr.set(i, arr.get(i).toString().trim());
        }
        if (foundFirst) {
            getInstance().error = "Syntax error\n";
        } else {
            //        NSLog(@"Separated TEXT - %@",arr);
        }
        return arr;
    }

    public ArrayList stringSeparateAllToArray(String string) {
        // Log.d(TAG, "± stringSeparateAllToArray for " + string);

        ArrayList arr = new ArrayList();
        int arrIndex = 0;
        int indexFirst = 0;
        boolean foundFirst = NO;
        if (string.length() > 0) {
            for (int i = 0; i < string.length(); i++) {
                if (string.substring(i, i + 1).equals("\"") && !foundFirst) {
                    foundFirst = YES;
                    indexFirst = i + 1;
                }
                if (string.substring(i, i + 1).equals("\"") && foundFirst && indexFirst != i + 1) {
                    foundFirst = NO;
                }
                if (string.substring(i, i + 1).equals(",") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    arrIndex = i + 1;
                    arr.add(string.substring(range.location, range.location + range.length));
                    arr.add(",");
                }
                if (string.substring(i, i + 1).equals("+") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("+");
                    }
                }
                if (string.substring(i, i + 1).equals("-") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("-");
                    }
                }
                if (string.substring(i, i + 1).equals("/") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("/");
                    }
                }
                if (string.substring(i, i + 1).equals("*") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("*");
                    }
                }
                if (string.substring(i, i + 1).equals("^") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("^");
                    }
                }
                if (string.substring(i, i + 1).equals("(") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add("(");
                    }
                }
                if (string.substring(i, i + 1).equals(")") && !foundFirst) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex);
                    String tmp = string.substring(range.location, range.location + range.length);
                    {
                        arrIndex = i + 1;
                        arr.add(tmp);
                        arr.add(")");
                    }
                }
                if (i == string.length() - 1) {
                    NSRange range = new NSRange(arrIndex, i - arrIndex + 1);
                    arr.add(string.substring(range.location, range.location + range.length));
                }
            }
        }
        if (foundFirst) {
            getInstance().error = "Syntax error\n";
        } else {
            //        NSLog(@"Separated ALL TEXT - %@",arr);
        }

        // for (int i=0; i<arr.size(); i++) Log.d(TAG, "± extracted arr->'" + arr.get(i).toString()+"'");
        return arr;
    }

}
